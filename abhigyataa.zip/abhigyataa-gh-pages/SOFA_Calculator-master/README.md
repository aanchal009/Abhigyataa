# SOFA_Calculator
The website will assist hospital staff in the intensive care unit (ICU) to assess the mortality risk of patients due to sepsis.

The information for the calculation is based on the Wikipedia's website: https://en.wikipedia.org/wiki/SOFA_score#Scoring.
